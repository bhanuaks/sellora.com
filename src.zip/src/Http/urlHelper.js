

export const fileBasePath = process.env.NEXT_PUBLIC_FILE_PATH || 'https://seller.sellora.com/';
export const sellerUrl = process.env.SELLER_URL || 'https://seller.sellora.com/';