import '../../../../../public/front/assets/css/help-center.css'

export default  function RootLayout({ children }) {
    return (
        <> 
        {children}
        </>
    )
}