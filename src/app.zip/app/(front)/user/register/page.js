import { baseUrl } from '@/Http/helper'
import Link from 'next/link'
import React from 'react'
import UserRegisterPage from './userRegisterPage'

function page() {
  return (
      <UserRegisterPage />
  )
}

export default page